Members:
c1kwongk

Brief User Guide:

	- Input file must be named favs.json
	
	- Links are rendered through the browser by default, you may use iFrame instead by setting the option from the Option button on the footer. However, some links are not abled to be rendered in an iFrame and will display nothing.
	
	- Special information in the tweet is color coded: links (red), user mentions (teal), hastags (yellow), author of tweet (blue); all of these (except hastags) can be clicked on for more information.